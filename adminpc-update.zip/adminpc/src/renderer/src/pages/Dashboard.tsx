import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import type { ImportedBook } from '../../../shared/types'
import { CountUp } from '../components/CountUp'
import { Icon } from '../components/Icon'
import { UNCATEGORISED } from '../components/LibraryTree'
import { Tabs } from '../components/Tabs'
import { EmptyState, ErrorNotice, LifecycleBadge, PageHeader, Spinner } from '../components/ui'
import { formatDay, formatNumber, formatRelative } from '../lib/format'
import { useAdminDashboard } from '../queries/admin'
import { useBooks } from '../queries/books'

type DashboardTab = 'attention' | 'published'

const initials = (name: string): string =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('') || '?'

export function Dashboard() {
  const { data: overview, isPending: overviewPending, error: overviewError, refetch: refetchOverview } = useAdminDashboard()
  const { data: books, isPending: booksPending, error: booksError, refetch: refetchBooks } = useBooks()
  const [tab, setTab] = useState<DashboardTab>('attention')

  // Categories are the imported books regrouped by their real `category` field.
  const folders = useMemo(() => {
    const map = new Map<string, ImportedBook[]>()
    for (const book of books ?? []) {
      const key = book.category?.trim() || UNCATEGORISED
      const list = map.get(key)
      if (list) list.push(book)
      else map.set(key, [book])
    }
    return [...map.entries()]
      .map(([name, items]) => ({
        name,
        books: items.length,
        chapters: items.reduce((n, b) => n + b.totalChapters, 0),
        authors: [...new Set(items.map((b) => b.authorName).filter(Boolean))]
      }))
      .sort((a, b) => b.books - a.books || a.name.localeCompare(b.name))
      .slice(0, 6)
  }, [books])

  if (overviewPending || booksPending) return <Spinner label="Loading dashboard…" />
  if (overviewError) return <ErrorNotice error={overviewError} onRetry={() => void refetchOverview()} />
  if (booksError) return <ErrorNotice error={booksError} onRetry={() => void refetchBooks()} />
  if (!overview || !books) return <EmptyState title="Dashboard data unavailable" />

  const publishedBooks = books.filter((book) => book.status === 'published')
  const totalImportedChapters = books.reduce((total, book) => total + book.totalChapters, 0)
  const publishedImportedChapters = books.reduce((total, book) => total + book.publishedChapters, 0)
  const importedWords = books.reduce((total, book) => total + (book.wordCount ?? 0), 0)
  const recentBooks = [...books].sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? '')).slice(0, 4)
  const attentionBooks = books.filter((book) => book.publishedChapters === 0)

  const rows = tab === 'attention' ? attentionBooks.slice(0, 6) : publishedBooks.slice(0, 6)

  return (
    <>
      <PageHeader title="Dashboard" subtitle="Platform overview and imported-book activity" />

      <div className="stats">
        <Stat title="Platform users" value={overview.totals.users} sub="Registered profiles" />
        <Stat title="Platform novels" value={overview.totals.novels} sub="All novels in the database" />
        <Stat title="Platform chapters" value={overview.totals.chapters} sub={`${formatNumber(overview.totals.publishedChapters)} published`} />
        <Stat title="Imported books" value={books.length} sub={`${formatNumber(publishedBooks.length)} published`} />
        <Stat title="Imported chapters" value={publishedImportedChapters} sub={`${formatNumber(totalImportedChapters)} total`} />
        <Stat title="Imported words" value={importedWords} sub="Only counts books returned by the import API" />
        <Stat title="Imports needing attention" value={attentionBooks.length} sub="Imported books with no published chapters" />
      </div>

      <div className="section-head">
        <h2 className="section-title">Recently imported</h2>
        <Link className="btn btn-outline btn-small" to="/books?sort=created">
          View all <Icon name="chevronRight" size={13} />
        </Link>
      </div>

      {recentBooks.length === 0 ? (
        <section className="card">
          <EmptyState title="No imported books yet">Use Import book to add the first one.</EmptyState>
        </section>
      ) : (
        <div className="doc-grid">
          {recentBooks.map((book) => (
            <Link key={book.id} to={`/books/${book.id}`} className="doc-card">
              <div className="doc-preview">
                <div className="doc-sheet">
                  <span className="doc-avatar">{book.title.charAt(0).toUpperCase()}</span>
                  <span className="skel-line" />
                  <span className="skel-line short" />
                </div>
                <span className="doc-cta">See details</span>
              </div>
              <div className="doc-title">{book.title}</div>
              <div className="doc-meta">
                <span>{book.authorName || 'Unknown author'} · {formatRelative(book.createdAt)}</span>
                <LifecycleBadge book={book} />
              </div>
            </Link>
          ))}
        </div>
      )}

      <div className="section-head">
        <h2 className="section-title">Categories</h2>
        <Link className="btn btn-outline btn-small" to="/books">
          View all <Icon name="chevronRight" size={13} />
        </Link>
      </div>

      {folders.length === 0 ? (
        <section className="card">
          <EmptyState title="No categories yet">Categories appear once books are imported.</EmptyState>
        </section>
      ) : (
        <div className="folder-grid">
          {folders.map((folder, i) => (
            <Link
              key={folder.name}
              to={folder.name === UNCATEGORISED ? '/books' : `/books?q=${encodeURIComponent(folder.name)}`}
              className={`folder-card${i === 0 ? ' is-dark' : ''}`}
            >
              <span className="folder-icon"><Icon name="folder" size={20} /></span>
              <div className="folder-name">{folder.name}</div>
              <div className="folder-meta">
                {formatNumber(folder.books)} {folder.books === 1 ? 'book' : 'books'} · {formatNumber(folder.chapters)} chapters
              </div>
              <div className="avatar-stack" aria-label={`Authors: ${folder.authors.join(', ')}`}>
                {folder.authors.slice(0, 3).map((author, n) => (
                  <span key={author} className={`avatar-sm tone-${n % 3}`} title={author}>{initials(author)}</span>
                ))}
                {folder.authors.length > 3 && <span className="avatar-sm tone-more">+{folder.authors.length - 3}</span>}
              </div>
            </Link>
          ))}
        </div>
      )}

      <h2 className="section-title">Imported books</h2>

      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: 'attention', label: 'No published chapter', count: attentionBooks.length },
          { id: 'published', label: 'Published', count: publishedBooks.length }
        ]}
      />

      <section className="card list-card">
        {rows.length === 0 ? (
          <EmptyState title={tab === 'attention' ? 'Nothing waiting' : 'No published books yet'}>
            {tab === 'attention' ? 'Every imported book has at least one published chapter.' : 'Publish an imported book to see it here.'}
          </EmptyState>
        ) : (
          <ul className="list">
            {rows.map((book) => (
              <li key={book.id}>
                <Link to={`/books/${book.id}`}>{book.title}</Link>
                <span className="muted small">{book.authorName} · {formatDay(book.createdAt)}</span>
                <LifecycleBadge book={book} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <h2 className="section-title">Recent platform activity</h2>

      <section className="card list-card">
        {overview.recentActivity.length === 0 ? (
          <EmptyState title="No activity recorded yet">Activity will appear here once the backend records user events.</EmptyState>
        ) : (
          <ul className="list">
            {overview.recentActivity.map((activity) => (
              <li key={activity.id}>
                <strong>{formatActivityType(activity.activityType)}</strong>
                <span className="muted small">
                  {activity.createdAt ? new Date(activity.createdAt).toLocaleString() : 'Time unavailable'}
                </span>
                <span className="muted small">
                  {activity.novelId ? `Novel: ${activity.novelId}` : activity.userId ? `User: ${activity.userId}` : 'Platform event'}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="muted small">
        Dashboard refreshed from the backend. Last response: {new Date(overview.generatedAt).toLocaleString()}.
      </p>
    </>
  )
}

function Stat({ title, value, sub }: { title: string; value: number; sub: string }) {
  return (
    <div className="stat-col">
      <div className="stat">
        <div className="stat-title">{title}</div>
        <div className="stat-value">
          <CountUp value={value} />
        </div>
        <div className="muted small">{sub}</div>
      </div>
    </div>
  )
}

function formatActivityType(value: string): string {
  return value.replace(/[_-]+/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase())
}
