import { useQuery } from '@tanstack/react-query'
import type { ReactNode } from 'react'
import { ErrorNotice, PageHeader, Spinner } from '../components/ui'
import { api } from '../lib/bridge'
import { formatDateTime } from '../lib/format'
import { useAuth } from '../state/auth'
import { useSettings, type DensityPref, type MotionPref, type SidebarStartup } from '../state/settings'

function SettingRow({ title, hint, children }: { title: string; hint: string; children: ReactNode }) {
  return (
    <div className="setting-row">
      <div className="setting-text">
        <strong>{title}</strong>
        <span className="muted small">{hint}</span>
      </div>
      <div className="setting-control">{children}</div>
    </div>
  )
}

function Segmented<T extends string>(props: {
  label: string
  value: T
  options: { value: T; label: string }[]
  onChange: (value: T) => void
}) {
  return (
    <div className="segmented" role="radiogroup" aria-label={props.label}>
      {props.options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={o.value === props.value}
          className={`segmented-item${o.value === props.value ? ' is-selected' : ''}`}
          onClick={() => props.onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

function Switch({ checked, label, onChange }: { checked: boolean; label: string; onChange: (next: boolean) => void }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`switch${checked ? ' is-on' : ''}`} onClick={() => onChange(!checked)}>
      <span className="switch-knob" />
    </button>
  )
}

export function Settings() {
  const { state, signOut } = useAuth()
  const { settings, update, reset } = useSettings()
  const info = useQuery({ queryKey: ['appInfo'], queryFn: api.appInfo, staleTime: Infinity })
  // GET / on the backend — the unauthenticated health check.
  const health = useQuery({ queryKey: ['health'], queryFn: api.health, retry: false, staleTime: 0, refetchOnWindowFocus: false })
  const user = state.status === 'signed_in' ? state.user : null

  return (
    <>
      <PageHeader title="Settings" subtitle="Preferences are saved on this computer. Account, backend and app details are below." />

      <section className="card">
        <div className="row between">
          <h2>Preferences</h2>
          <button className="btn btn-outline btn-small" onClick={reset}>
            Reset to defaults
          </button>
        </div>

        <SettingRow title="Animations" hint="Follow Windows' reduce-motion setting, or force animations on or off.">
          <Segmented<MotionPref>
            label="Animations"
            value={settings.motion}
            onChange={(motion) => update({ motion })}
            options={[
              { value: 'system', label: 'Follow system' },
              { value: 'full', label: 'Full' },
              { value: 'reduced', label: 'Reduced' }
            ]}
          />
        </SettingRow>

        <SettingRow title="Density" hint="How much space tables, lists and cards use.">
          <Segmented<DensityPref>
            label="Density"
            value={settings.density}
            onChange={(density) => update({ density })}
            options={[
              { value: 'comfortable', label: 'Comfortable' },
              { value: 'compact', label: 'Compact' }
            ]}
          />
        </SettingRow>

        <SettingRow title="Sidebar on startup" hint="What the secondary sidebar does when the app opens.">
          <Segmented<SidebarStartup>
            label="Sidebar on startup"
            value={settings.sidebarStartup}
            onChange={(sidebarStartup) => update({ sidebarStartup })}
            options={[
              { value: 'remember', label: 'Remember last' },
              { value: 'open', label: 'Always open' },
              { value: 'closed', label: 'Always closed' }
            ]}
          />
        </SettingRow>

        <SettingRow title="Review reminder" hint="Show the “Needs review” card at the bottom of the sidebar.">
          <Switch checked={settings.showReviewCard} label="Show the review reminder" onChange={(showReviewCard) => update({ showReviewCard })} />
        </SettingRow>
      </section>

      <section className="card">
        <div className="row between">
          <h2>Account</h2>
          <button className="btn btn-danger btn-small" onClick={() => void signOut()}>
            Sign out
          </button>
        </div>
        <dl className="kv">
          <dt>Signed in as</dt><dd>{user?.email}</dd>
          <dt>Role</dt><dd>{user?.role}</dd>
        </dl>
        <p className="muted small">Administrator access is enforced by the backend on every request; this screen only reflects your session.</p>
      </section>

      <section className="card">
        <div className="row between">
          <h2>Backend status</h2>
          <button className="btn btn-small" onClick={() => void health.refetch()} disabled={health.isFetching}>
            {health.isFetching ? 'Checking…' : 'Check again'}
          </button>
        </div>
        {health.isPending ? (
          <Spinner label="Contacting backend… (a sleeping server can take a minute)" />
        ) : health.error ? (
          <ErrorNotice error={health.error} />
        ) : (
          <dl className="kv">
            <dt>Status</dt>
            <dd><span className={`badge ${health.data.status === 'ok' ? 'badge-published' : 'badge-unpublished'}`}>{health.data.status ?? `HTTP ${health.data.httpStatus}`}</span></dd>
            <dt>Service</dt><dd>{health.data.service ?? '—'}</dd>
            <dt>Response time</dt><dd>{health.data.latencyMs} ms</dd>
            <dt>Server time</dt><dd>{formatDateTime(health.data.timestamp)}</dd>
          </dl>
        )}
      </section>

      <section className="card">
        <h2>Application</h2>
        {!info.data ? (
          <Spinner />
        ) : (
          <dl className="kv">
            <dt>Application</dt><dd>{info.data.name} {info.data.version}</dd>
            <dt>Environment</dt><dd>{info.data.environment}</dd>
            <dt>API host</dt><dd>{info.data.apiHost}</dd>
            <dt>Platform</dt><dd>{info.data.platform}</dd>
          </dl>
        )}
        <p className="muted small">The API URL is fixed at build time (see .env.example).</p>
      </section>
    </>
  )
}
