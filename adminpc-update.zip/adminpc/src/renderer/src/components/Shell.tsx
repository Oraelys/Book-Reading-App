import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { lifecycleOf } from '../../../shared/lifecycle'
import { formatNumber } from '../lib/format'
import { useBooks } from '../queries/books'
import { useAuth } from '../state/auth'
import { useSettings, type SidebarStartup } from '../state/settings'
import { Icon, type IconName } from './Icon'
import { LibraryTree } from './LibraryTree'
import { WindowControls } from './WindowControls'

/** Main nav. Items after the divider have no backend endpoint yet (BACKEND GAP). Settings and sign-out live at the bottom. */
const RAIL: { to: string; label: string; icon: IconName; end?: boolean; gap?: boolean }[] = [
  { to: '/', label: 'Dashboard', icon: 'grid', end: true },
  { to: '/books', label: 'Imported books', icon: 'book' },
  { to: '/import', label: 'Import book', icon: 'upload' },
  { to: '/users', label: 'Users', icon: 'users' },
  { to: '/authors', label: 'Authors — backend gap', icon: 'pen', gap: true },
  { to: '/activity', label: 'Activity — backend gap', icon: 'activity', gap: true },
  { to: '/moderation', label: 'Moderation — backend gap', icon: 'shield', gap: true },
  { to: '/analytics', label: 'Analytics — backend gap', icon: 'chart', gap: true }
]

/** Height of the sliding active-item indicator, in px (keep in sync with .rail-indicator). */
const INDICATOR_HEIGHT = 22

const SHORTCUT = /Mac|iPhone|iPad/.test(navigator.userAgent) ? '⌘ K' : 'Ctrl K'

/** Where the user is, derived from the route only. */
function locate(pathname: string): { module: string; trail: { label: string; to?: string }[] } {
  if (pathname === '/') return { module: 'Dashboard', trail: [{ label: 'Overview' }, { label: 'Dashboard' }] }
  if (pathname === '/books') return { module: 'Imported books', trail: [{ label: 'Books' }, { label: 'Imported books' }] }
  if (pathname.startsWith('/books/')) {
    return { module: 'Imported books', trail: [{ label: 'Books' }, { label: 'Imported books', to: '/books' }, { label: 'Review' }] }
  }
  if (pathname === '/import') return { module: 'Import book', trail: [{ label: 'Books' }, { label: 'Import book' }] }
  if (pathname === '/users') return { module: 'Users', trail: [{ label: 'Administration' }, { label: 'Users' }] }
  if (pathname === '/settings') return { module: 'Settings', trail: [{ label: 'System' }, { label: 'Settings' }] }
  const name = pathname.slice(1).split('/')[0] ?? ''
  const label = name.charAt(0).toUpperCase() + name.slice(1)
  return { module: label || 'Dashboard', trail: [{ label: 'Administration' }, { label }] }
}

function useIsActive(to: string, prefix = false): boolean {
  const loc = useLocation()
  const [path = '/', query = ''] = to.split('?')
  const wantSearch = query ? `?${query}` : ''
  return (prefix ? loc.pathname.startsWith(path) : loc.pathname === path) && loc.search === wantSearch
}

function SideLink({ to, icon, label, count }: { to: string; icon: IconName; label: string; count?: number }) {
  const active = useIsActive(to)
  return (
    <Link to={to} className={`side-link${active ? ' active' : ''}`}>
      <Icon name={icon} size={18} />
      <span>{label}</span>
      {count !== undefined && <span className="count">{count}</span>}
    </Link>
  )
}

function SubLink({ to, label, count }: { to: string; label: string; count?: number }) {
  const active = useIsActive(to)
  return (
    <Link to={to} className={`sub-link${active ? ' active' : ''}`}>
      <span>{label}</span>
      {count !== undefined && <span className="count">{count}</span>}
    </Link>
  )
}

const rememberedCollapsed = (): boolean => {
  try {
    return localStorage.getItem('inkwell.sidebar.collapsed') === '1'
  } catch {
    return false
  }
}

const startCollapsed = (pref: SidebarStartup): boolean => (pref === 'open' ? false : pref === 'closed' ? true : rememberedCollapsed())

export function Shell() {
  const { state, signOut } = useAuth()
  const { settings } = useSettings()
  const { pathname } = useLocation()
  const user = state.status === 'signed_in' ? state.user : null
  const { data } = useBooks()
  const books = useMemo(() => data ?? [], [data])

  const [collapsed, setCollapsed] = useState(() => startCollapsed(settings.sidebarStartup))
  const [menu, setMenu] = useState(false)
  const [groupOpen, setGroupOpen] = useState<boolean | null>(null)
  const [libraryQuery, setLibraryQuery] = useState('')
  const [indicatorY, setIndicatorY] = useState<number | null>(null)
  const [indicatorReady, setIndicatorReady] = useState(false)
  const frameRef = useRef<HTMLDivElement>(null)
  const searchRef = useRef<HTMLInputElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  const here = locate(pathname)
  const onBooks = pathname.startsWith('/books')
  const booksOpen = groupOpen ?? onBooks
  const displayName = user?.username ?? user?.email.split('@')[0] ?? 'Admin'

  const count = (l: 'draft' | 'published' | 'unpublished') => books.filter((b) => lifecycleOf(b) === l).length
  const totalChapters = books.reduce((n, b) => n + b.totalChapters, 0)
  const publishedChapters = books.reduce((n, b) => n + b.publishedChapters, 0)
  const pct = totalChapters > 0 ? Math.round((publishedChapters / totalChapters) * 100) : 0
  const needReview = books.filter((b) => b.publishedChapters === 0).length

  const setSidebar = (next: boolean): void => {
    setCollapsed(next)
    try {
      localStorage.setItem('inkwell.sidebar.collapsed', next ? '1' : '0')
    } catch {
      /* storage unavailable: keep in memory */
    }
  }

  // The purple indicator sits beside the active main-nav button and slides to the next one.
  const placeIndicator = useCallback(() => {
    const frame = frameRef.current
    const active = frame?.querySelector<HTMLElement>('.rail .rail-btn.active')
    if (!frame || !active) {
      setIndicatorY(null)
      return
    }
    const f = frame.getBoundingClientRect()
    const a = active.getBoundingClientRect()
    setIndicatorY(Math.round(a.top - f.top + a.height / 2 - INDICATOR_HEIGHT / 2))
  }, [])

  useLayoutEffect(() => {
    placeIndicator()
  }, [pathname, placeIndicator])

  useEffect(() => {
    const frame = frameRef.current
    if (!frame) return
    const observer = new ResizeObserver(placeIndicator)
    observer.observe(frame)
    // Switch transitions on only after the first placement, so it doesn't slide in from the top on load.
    const raf = requestAnimationFrame(() => setIndicatorReady(true))
    return () => {
      observer.disconnect()
      cancelAnimationFrame(raf)
    }
  }, [placeIndicator])

  // Ctrl/Cmd+K focuses the library search (opening the sidebar first if it is hidden).
  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        if (collapsed) setSidebar(false)
        window.setTimeout(() => {
          searchRef.current?.focus()
          searchRef.current?.select()
        }, collapsed ? 360 : 0)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [collapsed])

  // Close the account menu on outside click or Escape.
  useEffect(() => {
    if (!menu) return
    const close = (e: MouseEvent | KeyboardEvent): void => {
      if (e instanceof KeyboardEvent) {
        if (e.key === 'Escape') setMenu(false)
        return
      }
      if (!(e.target as HTMLElement).closest('.user-menu')) setMenu(false)
    }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', close)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', close)
    }
  }, [menu])

  // New page → start at the top.
  useEffect(() => {
    contentRef.current?.scrollTo({ top: 0 })
  }, [pathname])

  return (
    /* Sky container: the whole window, with a 10px sky line all round. */
    <div className="app-frame" ref={frameRef}>
      <div className="drag-strip" />

      <aside className="rail" aria-label="Main navigation">
        <WindowControls />

        <Link to="/" className="rail-btn rail-logo" title="Home" aria-label="Go to the dashboard">
          <Icon name="feather" size={18} />
        </Link>
        <span className="rail-divider" />

        <nav className="rail-nav">
          {RAIL.map((item, i) => (
            <div key={item.to} className="rail-item">
              {item.gap && !RAIL[i - 1]?.gap && <span className="rail-sep" />}
              <NavLink
                to={item.to}
                end={item.end}
                title={item.label}
                aria-label={item.label}
                className={({ isActive }) => `rail-btn${isActive ? ' active' : ''}${item.gap ? ' dim' : ''}`}
              >
                <Icon name={item.icon} size={17} />
              </NavLink>
            </div>
          ))}
        </nav>

        <span className="rail-spacer" />
        <span className="rail-divider" />

        <NavLink to="/settings" title="Settings" aria-label="Settings" className={({ isActive }) => `rail-btn${isActive ? ' active' : ''}`}>
          <Icon name="settings" size={17} />
        </NavLink>
        <button className="rail-btn" onClick={() => void signOut()} title="Sign out" aria-label="Sign out">
          <Icon name="logOut" size={17} />
        </button>
      </aside>

      <span
        className={`rail-indicator${indicatorY !== null ? ' is-visible' : ''}${indicatorReady ? ' is-ready' : ''}`}
        style={{ ['--y' as string]: `${indicatorY ?? 0}px` }}
        aria-hidden
      />

      {/* Dark container: holds the secondary nav and the light container. */}
      <div className={`panel${collapsed ? ' collapsed' : ''}`}>
        <aside className="sidebar" aria-label="Navigation" inert={collapsed}>
          <div className="sidebar-inner">
            <div className="sidebar-head">
              <button className="round-btn" onClick={() => setSidebar(true)} aria-label="Hide sidebar" title="Hide sidebar">
                <Icon name="chevronsLeft" size={16} />
              </button>
              <span key={here.module} className="sidebar-title">{here.module}</span>
              <Link to="/settings" className="round-btn" aria-label="Settings" title="Settings">
                <Icon name="settings" size={16} />
              </Link>
            </div>

            <label className="search-inset search-kbd">
              <Icon name="search" size={16} />
              <input
                ref={searchRef}
                type="search"
                placeholder="Search library"
                value={libraryQuery}
                onChange={(e) => setLibraryQuery(e.target.value)}
                aria-label="Search library"
              />
              <kbd className="kbd">{SHORTCUT}</kbd>
            </label>

            <div className="side-scroll">
              <SideLink to="/" icon="home" label="Dashboard" />

              <div className={`side-group${onBooks ? ' active' : ''}${booksOpen ? ' is-open' : ''}`}>
                <div className="side-group-head">
                  <Link to="/books" className="side-group-link">
                    <Icon name="library" size={18} />
                    <span>Imported books</span>
                  </Link>
                  <button
                    className="chev-btn"
                    onClick={() => setGroupOpen(!booksOpen)}
                    aria-expanded={booksOpen}
                    aria-label={booksOpen ? 'Collapse imported books' : 'Expand imported books'}
                  >
                    <Icon name="chevronUp" size={15} className="chev" />
                  </button>
                </div>
                <div className={`collapse${booksOpen ? ' open' : ''}`} inert={!booksOpen}>
                  <div className="collapse-inner">
                    <div className="sub-list">
                      <SubLink to="/books" label="All books" count={books.length} />
                      <SubLink to="/books?status=draft" label="Draft" count={count('draft')} />
                      <SubLink to="/books?status=published" label="Published" count={count('published')} />
                      <SubLink to="/books?status=unpublished" label="Unpublished" count={count('unpublished')} />
                      <SubLink to="/books?sort=created" label="Recently imported" />
                    </div>
                  </div>
                </div>
              </div>

              <SideLink to="/import" icon="upload" label="Import book" />
              <SideLink to="/users" icon="users" label="Users" />

              <div className="side-sep" />
              <div className="side-label">Library</div>
              <LibraryTree books={books} query={libraryQuery} />

              <Link to="/import" className="side-dashed">
                <span className="plus-dot"><Icon name="plus" size={13} /></span>
                Import book
              </Link>
            </div>

            {settings.showReviewCard && needReview > 0 && (
              <div className="side-card">
                <span className="side-card-icon"><Icon name="checkCircle" size={22} /></span>
                <strong>Needs review</strong>
                <p>
                  {formatNumber(needReview)} imported {needReview === 1 ? 'book has' : 'books have'} no published chapter yet.
                </p>
                <Link to="/books" className="btn">Open imported books</Link>
              </div>
            )}
          </div>
        </aside>

        {/* Light container: the page itself. */}
        <main className="main">
          <header className="topbar">
            <div className="topbar-row">
              {collapsed && (
                <button className="round-btn round-btn-light" onClick={() => setSidebar(false)} aria-label="Show sidebar" title="Show sidebar">
                  <Icon name="chevronsRight" size={16} />
                </button>
              )}

              {totalChapters > 0 && (
                <div className="progress-card" title="Published chapters across imported books">
                  <span className="progress-icon"><Icon name="book" size={18} /></span>
                  <div className="progress-body">
                    <div className="progress-meta">
                      <strong>Imported chapters published</strong>
                      <span className="muted">{formatNumber(publishedChapters)} / {formatNumber(totalChapters)}</span>
                    </div>
                    <div className="progress-track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
                      <div className="progress-fill" style={{ ['--pct' as string]: `${pct}%` }} />
                    </div>
                  </div>
                </div>
              )}

              <span className="topbar-spacer" />

              <Link to="/import" className="btn btn-primary">
                <Icon name="plus" size={15} /> Import book
              </Link>

              <div className="user-menu">
                <button className="avatar-btn" onClick={() => setMenu((m) => !m)} aria-expanded={menu} aria-label="Account menu" title={user?.email}>
                  {displayName.slice(0, 1).toUpperCase()}
                </button>
                {menu && (
                  <div className="menu" role="menu">
                    <div className="menu-user">
                      <strong>{displayName}</strong>
                      <span className="muted small">{user?.email}</span>
                    </div>
                    <button role="menuitem" onClick={() => void signOut()}>
                      <Icon name="logOut" size={15} /> Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>

            <nav className="crumbs" aria-label="Breadcrumb">
              {here.trail.map((c, i) => (
                <span key={`${c.label}-${i}`} className="crumb-item">
                  {i > 0 && <Icon name="chevronRight" size={13} className="crumb-sep" />}
                  {c.to ? <Link to={c.to}>{c.label}</Link> : <span className={i === here.trail.length - 1 ? 'crumb-current' : ''}>{c.label}</span>}
                </span>
              ))}
              {pathname === '/books' && <span className="crumb-count">{books.length}</span>}
            </nav>
          </header>

          <div className="content" ref={contentRef}>
            <div className="page" key={pathname}>
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
