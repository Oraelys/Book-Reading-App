import { QueryClientProvider } from '@tanstack/react-query'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'
import { queryClient } from './lib/query-client'
import { AuthProvider } from './state/auth'
import { applySettings, loadSettings, SettingsProvider } from './state/settings'
import { ToastProvider } from './state/toast'
import './styles.css'

applySettings(loadSettings()) // no flash of the wrong density / motion on startup

createRoot(document.getElementById('root') as HTMLElement).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <SettingsProvider>
        <AuthProvider>
          <ToastProvider>
            <App />
          </ToastProvider>
        </AuthProvider>
      </SettingsProvider>
    </QueryClientProvider>
  </StrictMode>
)
